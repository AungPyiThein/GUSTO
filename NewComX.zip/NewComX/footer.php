<div id="footer">
  Powered By <?php the_title(); ?>
</div>
